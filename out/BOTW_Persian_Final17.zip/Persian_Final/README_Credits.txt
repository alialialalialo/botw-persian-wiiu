Persian translation of The Legend of Zelda: Breath of the Wild
ترجمهٔ فارسی بازی زلدا: نفس وحش

Original Persian translation (Switch version) by Majid Hoshyar (مجید هوشیار).
مترجم و سازندهٔ ترجمهٔ فارسی اصلی: آقای مجید هوشیار
https://www.radoo.ir/author/majidh1/

Wii U adaptation / تطبیق نسخهٔ Wii U: ali123qp (Telegram)

This graphic pack only adapts that translation (text order, fonts, control codes)
for the Wii U 1.5.0 (EU) version running in Cemu. All translation credit belongs to the original author.
این گرافیک‌پک فقط ترجمهٔ ایشان را برای نسخهٔ Wii U (1.5.0 اروپا) در Cemu سازگار می‌کند؛ همهٔ اعتبار ترجمه متعلق به سازندهٔ اصلی است.

Note / توضیح: some quest, tips and NPC-shout texts were lightly edited for natural wording and to fix wrong or truncated sentences (by the Wii U adapter).
برخی متن‌های ماموریت‌ها، نکته‌ها و فریادهای NPC برای روان‌تر شدن و اصلاح جمله‌های غلط یا ناقص، کم‌وبیش ویرایش شده‌اند.
